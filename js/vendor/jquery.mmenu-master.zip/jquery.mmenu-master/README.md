jquery.mmenu
===============

A jQuery plugin for creating slick, app look-alike sliding menus for you mobile website.
For examples and the complete documentation, visit http://mmenu.frebsite.nl
